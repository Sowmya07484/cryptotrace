from fastapi import FastAPI, HTTPException

from app.models.investigation import InvestigationRequest
from app.services.tracer import trace_wallet


app = FastAPI(
    title="CryptoTrace Backend",
    version="0.1.0",
)


@app.get("/")
def root():
    return {
        "project": "CryptoTrace",
        "status": "running",
    }


@app.post("/investigate")
async def investigate(
    request: InvestigationRequest,
):

    wallet_address = (
        request.wallet_address.strip()
    )

    if not wallet_address:
        raise HTTPException(
            status_code=400,
            detail="wallet_address cannot be empty",
        )

    try:

        result = await trace_wallet(
            wallet_address,
            request.max_hops,
        )

        return result

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e),
        )

    except Exception as e:

        raise HTTPException(
            status_code=502,
            detail=str(e),
        )