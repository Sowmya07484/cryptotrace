import re

from app.services.blockchain import get_transactions


MAX_WALLETS_PER_HOP = 10
MAX_TRANSACTIONS_PER_WALLET = 20


def is_valid_eth_address(address: str) -> bool:
    return bool(
        re.fullmatch(
            r"0x[a-fA-F0-9]{40}",
            address or "",
        )
    )


async def trace_wallet(
    start_address: str,
    max_hops: int = 2,
):
    start_address = start_address.strip()

    # Validate starting wallet
    if not is_valid_eth_address(start_address):
        raise ValueError("Invalid Ethereum wallet address")

    visited = {
        start_address.lower()
    }

    queue = [
        (start_address, 0)
    ]

    wallets = []
    edges = []
    all_transactions = []

    truncated = False

    while queue:
        current_address, current_hop = queue.pop(0)

        transactions = await get_transactions(
            current_address,
            page=1,
            offset=MAX_TRANSACTIONS_PER_WALLET,
        )

        wallet_transactions = []

        for tx in transactions:
            tx_data = tx.model_dump()

            wallet_transactions.append(tx_data)
            all_transactions.append(tx_data)

            # Only process outgoing transactions
            if tx.from_address.lower() != current_address.lower():
                continue

            # Ignore transactions without destination
            if not tx.to_address:
                continue

            destination = tx.to_address.strip()

            # Ignore malformed addresses
            if not is_valid_eth_address(destination):
                continue

            # Do not create edges beyond requested hop depth
            if current_hop >= max_hops:
                continue

            # Add graph edge
            edges.append(
                {
                    "from": tx.from_address,
                    "to": destination,
                    "transaction_hash": tx.hash,
                    "asset": tx.asset,
                    "value": tx.value,
                    "transaction_type": tx.transaction_type,
                    "hop": current_hop + 1,
                }
            )

            destination_key = destination.lower()

            # Already traced
            if destination_key in visited:
                continue

            # Count wallets already waiting at next hop
            wallets_at_next_hop = sum(
                1
                for _, hop in queue
                if hop == current_hop + 1
            )

            # Prevent uncontrolled API expansion
            if wallets_at_next_hop >= MAX_WALLETS_PER_HOP:
                truncated = True
                continue

            visited.add(destination_key)

            queue.append(
                (
                    destination,
                    current_hop + 1,
                )
            )

        wallets.append(
            {
                "address": current_address,
                "hop": current_hop,
                "transaction_count": len(wallet_transactions),
                "transactions": wallet_transactions,
            }
        )

    return {
        "wallet_address": start_address,
        "network": "ethereum",
        "max_hops": max_hops,
        "wallets": wallets,
        "edges": edges,
        "transactions": all_transactions,
        "tracing": {
            "wallets_traced": len(wallets),
            "max_wallets_per_hop": MAX_WALLETS_PER_HOP,
            "max_transactions_per_wallet": MAX_TRANSACTIONS_PER_WALLET,
            "truncated": truncated,
        },
    }